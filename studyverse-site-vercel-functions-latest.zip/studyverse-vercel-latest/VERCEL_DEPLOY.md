# StudyVerse / TonanStudy — Vercel本番デプロイ手順

このZIPはExpressをVercel Functionsとして動かす最新構成です。`api/index.ts`、`server/_core/app.ts`、`vercel.json`を含みます。

## Vercelに設定する環境変数

Vercelの Project Settings → Environment Variables に、Production／Preview／Developmentの必要な環境へ登録してください。

必須：

- `DATABASE_URL` — MySQL/TiDB接続URL
- `JWT_SECRET` — 長くランダムなセッション署名キー
- `VITE_APP_ID` — Manus OAuthアプリID
- `OAUTH_SERVER_URL` — Manus OAuthサーバーURL
- `VITE_OAUTH_PORTAL_URL` — Manus OAuthログインポータルURL
- `OWNER_OPEN_ID` — 管理者のOpen ID
- `OWNER_NAME` — 管理者名
- `BUILT_IN_FORGE_API_URL` — Manus内蔵API URL
- `BUILT_IN_FORGE_API_KEY` — Manus内蔵APIキー
- `VITE_FRONTEND_FORGE_API_URL` — フロントエンド用内蔵API URL
- `VITE_FRONTEND_FORGE_API_KEY` — フロントエンド用内蔵APIキー

通知を使う場合：

- `VAPID_PUBLIC_KEY`
- `VAPID_PRIVATE_KEY`
- `VAPID_SUBJECT`（例：`mailto:admin@example.com`）

`JWT_SECRET`、データベースURL、APIキーはGitHubやZIPへ書き込まないでください。

## GitHubからVercelへデプロイ

```bash
git init
git add .
git commit -m "Deploy StudyVerse to Vercel"
git branch -M main
git remote add origin https://github.com/<ユーザー名>/<リポジトリ名>.git
git push -u origin main
```

その後、Vercelで「Add New Project」→対象GitHubリポジトリ→Importを選択します。

- Framework Preset：Other
- Build Command：`pnpm run build`
- Output Directory：`dist/public`
- Install Command：`pnpm install --frozen-lockfile`

`vercel.json`に同じ設定を含めているため、通常は自動認識されます。環境変数を登録してDeployします。

## ZIPを直接使う場合

1. ZIPを展開します。
2. 展開先をGitHubへアップロードします（GitHubの「Add file」→「Upload files」）。
3. `node_modules`、`.env`、`dist`はアップロードしません。
4. GitHubリポジトリをVercelからImportします。
5. 上記の環境変数をVercelへ登録してDeployします。

## データベース

本番DBへ接続できることを確認してから、ローカルまたは安全なCI環境で一度だけ実行します。

```bash
pnpm install
pnpm db:push
```

## OAuthの注意

Vercelの本番ドメインが決まったら、Manus OAuth側の許可済みリダイレクト先も本番ドメインに合わせて確認してください。Preview URLとProduction URLを混在させないでください。

## デプロイ後の確認

- `/` が表示される
- `/api/trpc` がFunctionとして応答する
- OAuthログイン後に本番ドメインへ戻る
- ログイン後のデータベース読み書きができる
- 画像アップロードと画像表示ができる
- VercelのFunctionsログに環境変数不足やDB接続エラーがない
